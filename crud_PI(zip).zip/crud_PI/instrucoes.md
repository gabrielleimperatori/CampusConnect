# Anotações de Backend
Prof. Iuri Santos

### Pra que serve uma API?
- Criar dados
- Listar dados
- Buscar dados
- Atualizar e remover dados

### Pré-requisitos

- node.js instalado
- npm
- mysql server
- cliente para teste (Thunder Client) (Postman ou Insomnia)

### Iniciar o projeto
```
npm init -y
```